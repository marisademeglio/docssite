function getLatest() {
    return "0.2.0";
}

function getReleases() {return ["0.2.0","0.1.0",];
}

export {
    getLatest, getReleases
}